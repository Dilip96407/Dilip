Scaffold - Web Application Toolkit
=======================================================================

Scaffold is a toolkit for building web applications. Web application 
frameworks, like Struts, provide the essential infrastructure most 
developers need to create applications. But there are still many 
reusable pieces that most applications need but frameworks don't 
typically provide. Scaffold is a home for classes that can be reused 
between applications but are not sexy enough (or sometimes too sexy) 
for a framework distribution. 

The bulk of Scaffold is being provided through the Commons. This 
is a Struts specific package is provided in the Struts source code 
distribution which builds on the classes provided there.

See build.html for requisite JARs.

###
